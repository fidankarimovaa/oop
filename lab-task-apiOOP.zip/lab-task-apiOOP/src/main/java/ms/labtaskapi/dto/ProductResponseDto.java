package ms.labtaskapi.dto;

public class ProductResponseDto {
    private String name;
    private double price;
    private int stockCount;
}
