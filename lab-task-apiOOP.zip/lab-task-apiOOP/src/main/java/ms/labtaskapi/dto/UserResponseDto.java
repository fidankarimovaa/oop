package ms.labtaskapi.dto;

public class UserResponseDto {
    private String userName;
    private String name;
    private String surname;
    private int age;
    private double balance;
    private boolean enable;
}
